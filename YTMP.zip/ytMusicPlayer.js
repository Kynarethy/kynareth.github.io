/*
  Author: Catsbit IO
          www.catsbit.ru
  Source link: https://io.catsbit.ru/javascript/ytMusicPlayer.js
  Use: <iframe id="youtubeplayer" width="50" height="50" src=""></iframe> to setup player
  Attention! Please do not delete this comment block
  Requires > JQuery
*/
function changeSong(vid, songartist, songtitle) {
    $('iframe#YTMP').attr('src', 'https://www.youtube.com/embed/' + vid + '?autoplay=1&showinfo=0&autohide=0&controls=2&enablejsapi=1');

    $('#songartist').text(songartist);
    $('#songtitle').text(songtitle);
}

//Playlist
var playlist = 'default';
var songs;
switch (playlist) {
    case 'default':
        songs = Array(
            'FYyCbKZIkgc, What I\'ve Waited For (feat. D. Brown), Vicetone',
            '6ed0N-5zLW8, Party Don\'t Stop, Darren Styles feat. Dougal & Gammer',
            '__CRWE-L45k, Symbolism, Electro-Light',
            'uzFH5v4MZpY, Lights (A.R.M.O.S. Remix), Rude Boy & Jackson',
            'OT9yvB6z7JY, Sad Story (Out Of Luck) (Burak Yeter Remix), Merk & Kremont & Ady Suleiman'
        );
}

/*PLAYER*/
var player;
//split items from plalist array
var randSong = Math.floor((Math.random() * songs.length));

//let's make some funcs
function showPlayButton() {
    $('#play').css('display', 'inline');
    $('#pause').css('display', 'none');
}
function showPauseButton() {
    $('#play').css('display', 'none');
    $('#pause').css('display', 'inline');
}
function splitItem(song) {
    var arrayParam = songs[song].split(', ');
    changeSong(arrayParam[0], arrayParam[1], arrayParam[2]);
}
function FPlay(query) {
    for (i=0;i<songs.length;i++) {
        if (songs[i].substring(13) == query) {
            splitItem(i);
            break;
        }
    }
}
function onYouTubeIframeAPIReady() {
    player = new YT.Player('YTMP', {
       events: {
           'onReady': onPlayerReady
       } 
    });
}
$('YTMP').on('load', function() {
    setInterval(function() {
        var state = player.getPlayerState();
        switch (state) {
            case 0: 
                console.log('Staqte: Complete');
                showPlayButton();
                break;
            case 1: 
                showPauseButton();
                break;
            case 2:
                showPlayButton();
                break;
        }
    }, 1000);
});
function onPlayerReady(event) {
    $('#play').on('click', function() {
        player.playVideo();
        showPauseButton();
    });
    $('#pause').on('click', function() {
       player.pauseVideo();
        showPlayButton();
    });
}
$('#prev').on('click', function() {
    if(randSong == 0) {
        randSong = songs.length - 1;
        splitItem(randSong);
    } else {
        randSong = randSong - 1;
        splitItem(randSong);
    }
});
$('#next').on('click', function() {
   if(randSong == songs.length - 1) {
       randSong = 0;
       splitItem(randSong);
   } else {
       randSong = randSong + 1;
       splitItem(randSong);
   }
});
var yts = document.createElement('script');
yts.src = 'https://www.youtube.com/player_api';
var parentScriptTag = document.getElementsByTagName('script')[0];
parentScriptTag.parentNode.insertBefore(yts, parentScriptTag);

FPlay('Symbolism, Electro-Light');